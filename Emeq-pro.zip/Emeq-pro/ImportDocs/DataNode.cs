﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportDocs
{
    /*  class DataNode
      {
      }*/
    public class DataNode
    {
        // Fields
        public List<DataNode> nodes;
        public DataNode parent;
        public string text;
        public int type;
    }
}

 

 

