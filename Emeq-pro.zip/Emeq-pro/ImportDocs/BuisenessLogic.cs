﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ImportDocs
{
    /*class BuisenessLogic
    {
    }
}
  internal class BuisenessLogic
{
    // Methods
    private static void ExecSql(string connString, string sql)
    {
        using (SqlConnection connection = new SqlConnection(connString))
        {
            SqlCommand command = new SqlCommand(sql, connection);
            connection.Open();
            command.ExecuteNonQuery();
        }
    }

        public static DataTable GetBooksTreeDataTable(string connString) => 
        GetDataTable(connString, " SELECT id, parent_id, title from tree_tab where (type =1 or type=3 and parent_id in (SELECT id from tree_tab where type =1)) or(type=4 and parent_id in (SELECT id from tree_tab where type =3 and parent_id in (SELECT id from tree_tab where type =1) ))or(type=5 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =3) and parent_id in (SELECT id from tree_tab where type =1)))order by id_path");
    private static DataTable GetDataTable(string connString, string sql)
    {
        using (SqlConnection connection = new SqlConnection(connString))
        {
            connection.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            return dataTable;
        }
    }

    public static DataTable GetDocumentTypesDataTable(string connString) => 
        GetDataTable(connString, "select doc_type_id, doc_type_name from doc_type_tab \r\n\t\t\t\t\twhere doc_type_tablecreated = 1 order by doc_type_name");

    public static void GetDotNetConnectionString(string globalAsaPath, out string connString, out string dsn, out string supportedFileTypes)
    {
        connString = dsn = "";
        supportedFileTypes = ".tif,.doc,.eml,.txt,.jpg,.xls,.ppt,.pdf,.gif,.htm,.html,.msg,.dwf,.dwg,.bmp,";
        string str = File.ReadAllText(globalAsaPath);
        char[] separator = new char[] { '\n' };
        foreach (string str2 in str.Split(separator))
        {
            string str3 = str2.Trim().ToUpper();
            if (str3.StartsWith("CONNECTIONSTRING"))
            {
                connString = str3.Split(new char[] { '"' })[1];
                int index = connString.IndexOf("PROVIDER");
                if (index >= 0)
                {
                    int num2 = connString.IndexOf(";", (int) (index + 1));
                    if (num2 >= 0)
                    {
                        connString = connString.Substring(0, index) + connString.Substring(num2 + 1);
                    }
                }
            }
            else if (str3.StartsWith("APPLICATION(\"DSN\")"))
            {
                dsn = str3.Split(new char[] { '"' })[3];
            }
            else if (str3.StartsWith("APPLICATION(\"FILETYPES\")"))
            {
                supportedFileTypes = str3.Split(new char[] { '"' })[3];
            }
        }
    }

    public static DataTable GetEnvironmentsDataTable(string connString) => 
        GetDataTable(connString, "SELECT TOP 1 * from env_tab");

    public static string[] GetFilesWithMultipleExtensions(string path, string extensions)
    {
        List<string> list = new List<string>();
        string str = extensions;
        char[] separator = new char[] { ',' };
        foreach (string str2 in str.Split(separator))
        {
            if (str2.Contains("."))
            {
                string str3 = str2.Trim().ToUpper();
                foreach (string str4 in Directory.GetFiles(path, str3.StartsWith("*") ? str3 : ("*" + str3)))
                {
                    if (str4.ToUpper().EndsWith(str3.StartsWith("*") ? str3.Substring(1) : str3))
                    {
                        list.Add(str4);
                    }
                }
            }
        }
        return list.ToArray();
    }

    public static string GetNextPartOrder(string connString, string fileMixId, string parentId)
    {
        string sql = "select max(A.part_order) as part \r\n\t\t\t\tfrom toc_tab A, tree_tab B \r\n                where A.id = B.id\r\n\t\t\t\tand A.book_id = " + fileMixId + " and B.parent_id =" + parentId;
        string scalar = GetScalar(connString, sql);
        if (scalar != "")
        {
            int num = int.Parse(scalar) + 1;
            return num.ToString();
        }
        return "1";
    }

    public static string GetNextVal(string connString, string sequence)
    {
        string sql = "set nocount on; insert into " + sequence + "(dummy) values (null); select @@IDENTITY as nextval";
        return GetScalar(connString, sql);
    }

    public static string GetParentPartLetter(string connString, string parentId)
    {
        string sql = "select part_letter from toc_tab where id =" + parentId;
        return GetScalar(connString, sql);
    }

    private static string GetScalar(string connString, string sql)
    {
        using (SqlConnection connection = new SqlConnection(connString))
        {
            connection.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            return ((dataTable.Rows.Count > 0) ? dataTable.Rows[0][0].ToString() : "");
        }
    }

    public static string InsertNewBranch(string connString, string name, string parentId, string parentPath, string rootPath)
    {
        string nextVal = GetNextVal(connString, "item_seq");
        string str2 = ((parentId == "0") || (parentId == "")) ? nextVal : (parentPath + @"\" + nextVal);
        string sql = "insert into tree_tab (id, book_id, parent_id, type,  \r\n\t\t\t\t\torder_number, title, id_path) values (" + nextVal + "," + nextVal + "," + parentId + ",1,999,'" + name.Replace("'", "''") + "','" + str2 + "')";
        ExecSql(connString, sql);
        string str4 = "insert into sm_tab (id, disk_folder, page_number_format) values ( " + nextVal + ",'" + str2 + "','00000')";
        ExecSql(connString, str4);
        Directory.CreateDirectory(rootPath + @"\" + str2);
        return nextVal;
    }

    public static string InsertNewDivider(string connString, string name, string parentId, string parentPath, string rootPath, string docTypeId, string fileMixId)
    {
        string nextVal = GetNextVal(connString, "item_seq");
        string str2 = parentPath + @"\" + nextVal;
        string sql = "insert into tree_tab (id, book_id, parent_id, type, cfg_id, \r\n\t\t\t\t\torder_number, title, id_path) values (" + nextVal + "," + fileMixId + "," + parentId + ",4," + docTypeId + ",999,'" + name.Replace("'", "''") + "','" + str2 + "')";
        ExecSql(connString, sql);
        string str4 = GetNextPartOrder(connString, fileMixId, parentId);
        string str5 = GetParentPartLetter(connString, parentId) + str4 + ".";
        string str6 = "insert into toc_tab (id, part_letter ,from_page_number ,\r\n\t\t\t\t\tto_page_number ,book_id, part_order) values ( " + nextVal + ",'" + str5 + "', -1, -1, " + fileMixId + "," + str4 + ")";
        ExecSql(connString, str6);
        string str7 = "insert into book_nav_tab (book_id, part_letter, page_start, page_end, main_part, ext_name)\r\n\t\t\t\t\tvalues ( " + fileMixId + ",'" + str5 + "',-1, -1, 'N', '-1')";
        ExecSql(connString, str7);
        if (!string.IsNullOrEmpty(docTypeId))
        {
            string str8 = "insert into cfg_" + docTypeId + "_tab(id,column_1,column_2,column_3) Values ('" + nextVal + "','" + name + "','" + rootPath + @"\" + str2 + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
            ExecSql(connString, str8);
        }
        return nextVal;
    }

    public static string InsertNewDocumentAndCopyFile(string connString, string name, string parentId, string parentPath, string rootPath, string docTypeId, string fileMixId, string origFilePath)
    {
        string nextVal = GetNextVal(connString, "item_seq");
        string str2 = parentPath + @"\" + nextVal;
        docTypeId = string.IsNullOrEmpty(docTypeId) ? "NULL" : docTypeId;
        string sql = "insert into tree_tab (id, book_id, parent_id, type, cfg_id, \r\n\t\t\t\t\torder_number, title, id_path) values (" + nextVal + "," + fileMixId + "," + parentId + ",5," + docTypeId + ",999,'" + name.Replace("'", "''") + "','" + str2 + "')";
        ExecSql(connString, sql);
        string str4 = GetNextPartOrder(connString, fileMixId, parentId);
        string str5 = GetParentPartLetter(connString, parentId) + str4 + ".";
        string str6 = "insert into toc_tab (id, part_letter ,from_page_number ,\r\n\t\t\t\t\tto_page_number ,book_id, part_order) values ( " + nextVal + ",'" + str5 + "', 1, 1, " + fileMixId + "," + str4 + ")";
        ExecSql(connString, str6);
        FileInfo info = new FileInfo(origFilePath);
        string str7 = "insert into book_nav_tab (book_id, part_letter, page_start, page_end, main_part, ext_name)\r\n\t\t\t\t\tvalues ( " + fileMixId + ",'" + str5 + "',1, 1, 'N', '" + info.Extension.ToLower() + "')";
        ExecSql(connString, str7);
        if (docTypeId != "NULL")
        {
            string str8 = "insert into cfg_" + docTypeId + "_tab(id,column_1,column_2,column_3) Values ('" + nextVal + "','" + name + "','" + rootPath + @"\" + str2 + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
            ExecSql(connString, str8);
        }
        int index = (parentPath + @"\").IndexOf(@"\" + fileMixId + @"\");
        string str9 = rootPath + @"\" + parentPath.Substring(0, index) + @"\" + fileMixId + @"\" + str5 + "00001";
        File.Copy(origFilePath, str9 + info.Extension.ToLower());
        string str10 = str9 + ".odf";
        return nextVal;
    }

    public static string InsertNewFileMix(string connString, string name, string parentId, string parentPath, string rootPath, string docTypeId)
    {
        string nextVal = GetNextVal(connString, "item_seq");
        string str2 = parentPath + @"\" + nextVal;
        docTypeId = string.IsNullOrEmpty(docTypeId) ? "NULL" : docTypeId;
        string sql = "insert into tree_tab (id, book_id, parent_id, type, cfg_id, \r\n\t\t\t\t\torder_number, title, id_path) values (" + nextVal + "," + nextVal + "," + parentId + ",3," + docTypeId + ",999,'" + name.Replace("'", "''") + "','" + str2 + "')";
        ExecSql(connString, sql);
        string str4 = "insert into sm_tab (id, disk_folder, page_number_format) values ( " + nextVal + ",'" + str2 + "','00000')";
        ExecSql(connString, str4);
        if (docTypeId != "NULL")
        {
            string str5 = "insert into cfg_" + docTypeId + "_tab(id,column_1,column_2,column_3) Values ('" + nextVal + "','" + name + "','" + rootPath + @"\" + str2 + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
            ExecSql(connString, str5);
        }
        Directory.CreateDirectory(rootPath + @"\" + str2);
        return nextVal;
    }
}
    internal class BuisenessLogic
{
    // Methods
    public BuisenessLogic();
    private static void ExecSql(string connString, string sql);
    public static DataTable GetBooksTreeDataTable(string connString);
    private static DataTable GetDataTable(string connString, string sql);
    public static DataTable GetDocumentTypesDataTable(string connString);
    public static void GetDotNetConnectionString(string globalAsaPath, out string connString, out string dsn, out string supportedFileTypes);
    public static DataTable GetEnvironmentsDataTable(string connString);
    public static string[] GetFilesWithMultipleExtensions(string path, string extensions);
    public static string GetNextPartOrder(string connString, string fileMixId, string parentId);
    public static string GetNextVal(string connString, string sequence);
    public static string GetParentPartLetter(string connString, string parentId);
    private static string GetScalar(string connString, string sql);
    public static string InsertNewBranch(string connString, string name, string parentId, string parentPath, string rootPath);
    public static string InsertNewDivider(string connString, string name, string parentId, string parentPath, string rootPath, string docTypeId, string fileMixId);
    public static string InsertNewDocumentAndCopyFile(string connString, string name, string parentId, string parentPath, string rootPath, string docTypeId, string fileMixId, string origFilePath);
    public static string InsertNewFileMix(string connString, string name, string parentId, string parentPath, string rootPath, string docTypeId);
}*/
    internal class BuisenessLogic
    {
        private static void ExecSql(string connString, string sql)
        {
            using (SqlConnection connection = new SqlConnection(connString))
            {
                SqlCommand command = new SqlCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        /*was before  public static DataTable GetBooksTreeDataTable(string connString)
          {
            return GetDataTable(connString, " SELECT id, parent_id, title from tree_tab where (type =1 or type=3 and parent_id in (SELECT id from tree_tab where type =1)) or(type=4 and parent_id in (SELECT id from tree_tab where type =3 and parent_id in (SELECT id from tree_tab where type =1) ))or(type=5 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =3) and parent_id in (SELECT id from tree_tab where type =1)))order by id_path");
          }*/

        //שונה ע"י שירה משפט ה
        ///SELECT 
        ///כדילגרום לכמה שיותר תיקיות פנימיות להיות מוצגות בזמן הרצת
        ///הEXE
        public static DataTable GetBooksTreeDataTable(string connString)
        {
            return GetDataTable(connString, "SELECT id, parent_id, title from tree_tab where (type =1 or type=3 and parent_id in (SELECT id from tree_tab where type =1))"+
                      " or(type=4 and parent_id in (SELECT id from tree_tab where type =3 and parent_id in (SELECT id from tree_tab where type =1) ))"+
					  " or(type=4 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =3 and parent_id in (SELECT id from tree_tab where type =1))))"+
					  " or(type=4 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =3 and parent_id in (SELECT id from tree_tab where type =1)))))"+
					   "or(type=4 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =3 and parent_id in (SELECT id from tree_tab where type =1))))))"+
					  "  or(type=4 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =3 and parent_id in (SELECT id from tree_tab where type =1)))))))"+
                     "  or(type=5 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =3) and parent_id in (SELECT id from tree_tab where type =1)))"+
					   " order by id_path");
        }  
        //זאת הפונקציה המקורית
       //  public static DataTable GetBooksTreeDataTable(string connString) => 
    //     GetDataTable(connString, " SELECT id, parent_id, title from tree_tab where (type =1 or type=3 and parent_id in (SELECT id from tree_tab where type =1)) or(type=4 and parent_id in (SELECT id from tree_tab where type =3 and parent_id in (SELECT id from tree_tab where type =1) ))or(type=5 and parent_id in (SELECT id from tree_tab where type =4 and parent_id in (SELECT id from tree_tab where type =3) and parent_id in (SELECT id from tree_tab where type =1)))order by id_path");
        private static DataTable GetDataTable(string connString, string sql)
        {
            using (SqlConnection connection = new SqlConnection(connString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                return dataTable;
            }
        }
       public static DataTable GetDocumentTypesDataTable(string connString)
       {
           return GetDataTable(connString, "select doc_type_id, doc_type_name from doc_type_tab \r\n\t\t\t\t\twhere doc_type_tablecreated = 1 order by doc_type_name");
       }
       //  public static DataTable GetDocumentTypesDataTable(string connString) => 
      //      GetDataTable(connString, "select doc_type_id, doc_type_name from doc_type_tab \r\n\t\t\t\t\twhere doc_type_tablecreated = 1 order by doc_type_name");

        public static void GetDotNetConnectionString(string globalAsaPath, out string connString, out string dsn, out string supportedFileTypes)
        {
            connString = dsn = "";
            supportedFileTypes = ".tif,.doc,.eml,.txt,.jpg,.xls,.ppt,.pdf,.gif,.htm,.html,.msg,.dwf,.dwg,.bmp,";
            string str = File.ReadAllText(globalAsaPath);
            char[] separator = new char[] { '\n' };
            foreach (string str2 in str.Split(separator))
            {
                string str3 = str2.Trim().ToUpper();
                if (str3.StartsWith("CONNECTIONSTRING"))
                {
                    connString = str3.Split(new char[] { '"' })[1];
                    int index = connString.IndexOf("PROVIDER");
                    if (index >= 0)
                    {
                        int num2 = connString.IndexOf(";", (int)(index + 1));
                        if (num2 >= 0)
                        {
                            connString = connString.Substring(0, index) + connString.Substring(num2 + 1);
                        }
                    }
                }
                else if (str3.StartsWith("APPLICATION(\"DSN\")"))
                {
                    dsn = str3.Split(new char[] { '"' })[3];
                }
                else if (str3.StartsWith("APPLICATION(\"FILETYPES\")"))
                {
                    supportedFileTypes = str3.Split(new char[] { '"' })[3];
                }
            }
        }
        public static DataTable GetEnvironmentsDataTable(string connString)
        {
           return GetDataTable(connString, "SELECT TOP 1 * from env_tab");
        }
        /*  public static DataTable GetEnvironmentsDataTable(string connString) => 
              GetDataTable(connString, "SELECT TOP 1 * from env_tab");*/

        public static string[] GetFilesWithMultipleExtensions(string path, string extensions)
        {
            List<string> list = new List<string>();
            string str = extensions;
            char[] separator = new char[] { ',' };
            foreach (string str2 in str.Split(separator))
            {
                if (str2.Contains("."))
                {
                    string str3 = str2.Trim().ToUpper();
                    foreach (string str4 in Directory.GetFiles(path, str3.StartsWith("*") ? str3 : ("*" + str3)))
                    {
                        if (str4.ToUpper().EndsWith(str3.StartsWith("*") ? str3.Substring(1) : str3))
                        {
                            list.Add(str4);
                        }
                    }
                }
            }
            return list.ToArray();
        }

        public static string GetNextPartOrder(string connString, string fileMixId, string parentId)
        {
            string sql = "select max(A.part_order) as part \r\n\t\t\t\tfrom toc_tab A, tree_tab B \r\n                where A.id = B.id\r\n\t\t\t\tand A.book_id = " + fileMixId + " and B.parent_id =" + parentId;
            string scalar = GetScalar(connString, sql);
            if (scalar != "")
            {
                int num = int.Parse(scalar) + 1;
                return num.ToString();
            }
            return "1";
        }

        public static string GetNextVal(string connString, string sequence)
        {
            string sql = "set nocount on; insert into " + sequence + "(dummy) values (null); select @@IDENTITY as nextval";
            return GetScalar(connString, sql);
        }

        public static string GetParentPartLetter(string connString, string parentId)
        {
            string sql = "select part_letter from toc_tab where id =" + parentId;
            return GetScalar(connString, sql);
        }

        private static string GetScalar(string connString, string sql)
        {
            using (SqlConnection connection = new SqlConnection(connString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                return ((dataTable.Rows.Count > 0) ? dataTable.Rows[0][0].ToString() : "");
            }
        }

        public static string InsertNewBranch(string connString, string name, string parentId, string parentPath, string rootPath)
        {
            string nextVal = GetNextVal(connString, "item_seq");
            string str2 = ((parentId == "0") || (parentId == "")) ? nextVal : (parentPath + @"\" + nextVal);
            string sql = "insert into tree_tab (id, book_id, parent_id, type,  \r\n\t\t\t\t\torder_number, title, id_path) values (" + nextVal + "," + nextVal + "," + parentId + ",1,999,'" + name.Replace("'", "''") + "','" + str2 + "')";
            ExecSql(connString, sql);
            string str4 = "insert into sm_tab (id, disk_folder, page_number_format) values ( " + nextVal + ",'" + str2 + "','00000')";
            ExecSql(connString, str4);
            Directory.CreateDirectory(rootPath + @"\" + str2);
            return nextVal;
        }

        public static string InsertNewDivider(string connString, string name, string parentId, string parentPath, string rootPath, string docTypeId, string fileMixId)
        {
            string nextVal = GetNextVal(connString, "item_seq");
            string str2 = parentPath + @"\" + nextVal;
            string sql = "insert into tree_tab (id, book_id, parent_id, type, cfg_id, \r\n\t\t\t\t\torder_number, title, id_path) values (" + nextVal + "," + fileMixId + "," + parentId + ",4," + docTypeId + ",999,'" + name.Replace("'", "''") + "','" + str2 + "')";
            ExecSql(connString, sql);
            string str4 = GetNextPartOrder(connString, fileMixId, parentId);
            string str5 = GetParentPartLetter(connString, parentId) + str4 + ".";
            string str6 = "insert into toc_tab (id, part_letter ,from_page_number ,\r\n\t\t\t\t\tto_page_number ,book_id, part_order) values ( " + nextVal + ",'" + str5 + "', -1, -1, " + fileMixId + "," + str4 + ")";
            ExecSql(connString, str6);
            string str7 = "insert into book_nav_tab (book_id, part_letter, page_start, page_end, main_part, ext_name)\r\n\t\t\t\t\tvalues ( " + fileMixId + ",'" + str5 + "',-1, -1, 'N', '-1')";
            ExecSql(connString, str7);
            
           /*?? string origFilePath = parentPath + @"\" + name;
            FileInfo info = new FileInfo(origFilePath);*/
            if (!string.IsNullOrEmpty(docTypeId))
            {
               string str8 = "insert into cfg_" + docTypeId + "_tab(id,column_1,column_2,column_3) Values ('" + nextVal + "','" + name + "','" + rootPath + @"\" + str2 + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
              //??   string str8 = "insert into cfg_" + docTypeId + "_tab(id,column_1,column_2,column_3) Values ('" + nextVal + "','" + name + "','" + rootPath + @"\" + str2 + "','" + info.LastWriteTime + "')";
                ExecSql(connString, str8);
            }
         //   System.IO.File.WriteAllText(@"D:\shira\Setup\try\here5.txt", "nextVal: " + nextVal);
            return nextVal;
        }
        //שינוי נסיוני ע"י שירה עבור הצגת מספר תיקיות פנימיות רב יש צורך לבדוק לאן מתויק לכן שינתי שוב
        public static string InsertNewDocumentAndCopyFile2(string connString, string name, string parentId, string parentPath, string rootPath, string docTypeId, string fileMixId, string origFilePath)
        {
            string nextVal = GetNextVal(connString, "item_seq");
            string str2 = parentPath + @"\" + nextVal;
            docTypeId = string.IsNullOrEmpty(docTypeId) ? "NULL" : docTypeId;
            string sql = "insert into tree_tab (id, book_id, parent_id, type, cfg_id, \r\n\t\t\t\t\torder_number, title, id_path) values (" + nextVal + "," + fileMixId + "," + parentId + ",5," + docTypeId + ",999,'" + name.Replace("'", "''") + "','" + str2 + "')";
            ExecSql(connString, sql);
            string str4 = GetNextPartOrder(connString, fileMixId, parentId);
            string str5 = GetParentPartLetter(connString, parentId) + str4 + ".";
            string str6 = "insert into toc_tab (id, part_letter ,from_page_number ,\r\n\t\t\t\t\tto_page_number ,book_id, part_order) values ( " + nextVal + ",'" + str5 + "', 1, 1, " + fileMixId + "," + str4 + ")";
            ExecSql(connString, str6);
            FileInfo info = new FileInfo(origFilePath);
            string str7 = "insert into book_nav_tab (book_id, part_letter, page_start, page_end, main_part, ext_name)\r\n\t\t\t\t\tvalues ( " + fileMixId + ",'" + str5 + "',1, 1, 'N', '" + info.Extension.ToLower() + "')";
            ExecSql(connString, str7);
            if (docTypeId != "NULL")
            {
               // string str8 = "insert into cfg_" + docTypeId + "_tab(id,column_1,column_2,column_3) Values ('" + nextVal + "','" + name + "','" + rootPath + @"\" + str2 + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                string str8 = "insert into cfg_" + docTypeId + "_tab(id,column_1,column_2,column_3) Values ('" + nextVal + "','" + name + "','" + rootPath + @"\" + str2 + "','" + info.LastWriteTime + "')";
                ExecSql(connString, str8);
            }
            int index = (parentPath + @"\").IndexOf(@"\" + fileMixId + @"\");
            string str9="";
            /*  if(NumOfFolder(parentPath)==3) //מקרה עבור הוספת חוצץ ובתוכו תיקיות
               str9= rootPath + @"\" + parentPath.Substring(0, index) + @"\" + fileMixId + @"\" + str5 + "00001";
              else
                 if (NumOfFolder(parentPath) == 4)
                     str9 = rootPath + @"\" + parentPath.Substring(0, index) + @"\" + str5 + "00001";
              else
                  str9 = rootPath + @"\" + parentPath.Substring(0, index - 6) + @"\" + str5 + "00001";*/
            bool d6 = true;
           /* switch (NumOfFolder(parentPath,"",connString))
                  {
                case 3:
                    str9 = rootPath + @"\" + parentPath.Substring(0, index) + @"\" + fileMixId + @"\" + str5 + "00001";
                    break;
                case 4:
                    str9 = rootPath + @"\" + parentPath.Substring(0, index-6) + @"\" + str5 + "00001";
                    break;
                case 5:
                  // str9 = rootPath + @"\" + parentPath.Substring(0, index - 6) + @"\" + str5 + "00001";
                     str9 = rootPath + @"\" + parentPath.Substring(0, index - 6*2) + @"\" + str5 + "00001";
                    break;
                case 6:

                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 2) + @"\" + str5 + "00001";
                    //    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 3) + @"\" + str5 + "00001";
                    break;
                case 7:
                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 3) + @"\" + str5 + "00001";
                    break;
                case 8:
                    System.IO.File.WriteAllText(@"D:\shira\Setup\try\Bdika8.txt", "here17");
                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 4) + @"\" + str5 + "00001";
                    break;
                case 9:
                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 5) + @"\" + str5 + "00001";
                    break;
                case 10:
                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 6) + @"\" + str5 + "00001";
                    break;
                case 11:
                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 7) + @"\" + str5 + "00001";
                    break;
                case 12:
                    System.IO.File.WriteAllText(@"D:\shira\Setup\try\Bdika12.txt", "here17");
                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 8) + @"\" + str5 + "00001";
                    break;
                case 13:
                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 9) + @"\" + str5 + "00001";
                    break;
                case 14:
                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 10) + @"\" + str5 + "00001";
                    break;
                case 15:
                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 11) + @"\" + str5 + "00001";
                    break;
                case 16:
                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 12) + @"\" + str5 + "00001";
                    break;
                case 17:
                    System.IO.File.WriteAllText(@"D:\shira\Setup\try\Bdika17.txt", "here17");
                    str9 = rootPath + @"\" + parentPath.Substring(0, index - 6 * 13) + @"\" + str5 + "00001";
                    break;
            }*/
            File.Copy(origFilePath, str9 + info.Extension.ToLower());
            string str10 = str9 + ".odf";
            return nextVal;
        }
        public static string InsertNewDocumentAndCopyFile(string connString, string name, string parentId, string parentPath, string rootPath, string docTypeId, string fileMixId, string origFilePath)
        {
            string nextVal = GetNextVal(connString, "item_seq");
            string str2 = parentPath + @"\" + nextVal;
            docTypeId = string.IsNullOrEmpty(docTypeId) ? "NULL" : docTypeId;
            string sql = "insert into tree_tab (id, book_id, parent_id, type, cfg_id, \r\n\t\t\t\t\torder_number, title, id_path) values (" + nextVal + "," + fileMixId + "," + parentId + ",5," + docTypeId + ",999,'" + name.Replace("'", "''") + "','" + str2 + "')";
            ExecSql(connString, sql);
            string str4 = GetNextPartOrder(connString, fileMixId, parentId);
            string str5 = GetParentPartLetter(connString, parentId) + str4 + ".";
            string str6 = "insert into toc_tab (id, part_letter ,from_page_number ,\r\n\t\t\t\t\tto_page_number ,book_id, part_order) values ( " + nextVal + ",'" + str5 + "', 1, 1, " + fileMixId + "," + str4 + ")";
            ExecSql(connString, str6);
            FileInfo info = new FileInfo(origFilePath);
            string str7 = "insert into book_nav_tab (book_id, part_letter, page_start, page_end, main_part, ext_name)\r\n\t\t\t\t\tvalues ( " + fileMixId + ",'" + str5 + "',1, 1, 'N', '" + info.Extension.ToLower() + "')";
            ExecSql(connString, str7);
            if (docTypeId != "NULL")
            {
                string str8 = "insert into cfg_" + docTypeId + "_tab(id,column_1,column_2,column_3) Values ('" + nextVal + "','" + name + "','" + rootPath + @"\" + str2 + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                ExecSql(connString, str8);
            }
            /*orginal int index = (parentPath + @"\").IndexOf(@"\" + fileMixId + @"\");
            string str9 = rootPath + @"\" + parentPath.Substring(0, index) + @"\" + fileMixId + @"\" + str5 + "00001";*/

            //  int index = NumOfFolder(str2,nextVal,connString);

            //שירה
            int index = InsertFile(str2, nextVal, connString);
            string str9;
            if (index == -10)
            {
                index = (parentPath + @"\").IndexOf(@"\" + fileMixId + @"\");
                str9 = rootPath + @"\" + parentPath.Substring(0, index) + @"\" + fileMixId + @"\" + str5 + "00001";
            }
            else
                str9 = rootPath + @"\" + parentPath.Substring(0, index) + @"\" + str5 + "00001";


            File.Copy(origFilePath, str9 + info.Extension.ToLower());
            string str10 = str9 + ".odf";
            return nextVal;
        }
        public static string InsertNewDocumentAndCopyFileorg(string connString, string name, string parentId, string parentPath, string rootPath, string docTypeId, string fileMixId, string origFilePath)
        {
            string nextVal = GetNextVal(connString, "item_seq");
            string str2 = parentPath + @"\" + nextVal;
            docTypeId = string.IsNullOrEmpty(docTypeId) ? "NULL" : docTypeId;
            string sql = "insert into tree_tab (id, book_id, parent_id, type, cfg_id, \r\n\t\t\t\t\torder_number, title, id_path) values (" + nextVal + "," + fileMixId + "," + parentId + ",5," + docTypeId + ",999,'" + name.Replace("'", "''") + "','" + str2 + "')";
            ExecSql(connString, sql);
            string str4 = GetNextPartOrder(connString, fileMixId, parentId);
            string str5 = GetParentPartLetter(connString, parentId) + str4 + ".";
            string str6 = "insert into toc_tab (id, part_letter ,from_page_number ,\r\n\t\t\t\t\tto_page_number ,book_id, part_order) values ( " + nextVal + ",'" + str5 + "', 1, 1, " + fileMixId + "," + str4 + ")";
            ExecSql(connString, str6);
            FileInfo info = new FileInfo(origFilePath);
            string str7 = "insert into book_nav_tab (book_id, part_letter, page_start, page_end, main_part, ext_name)\r\n\t\t\t\t\tvalues ( " + fileMixId + ",'" + str5 + "',1, 1, 'N', '" + info.Extension.ToLower() + "')";
            ExecSql(connString, str7);
            if (docTypeId != "NULL")
            {
                string str8 = "insert into cfg_" + docTypeId + "_tab(id,column_1,column_2,column_3) Values ('" + nextVal + "','" + name + "','" + rootPath + @"\" + str2 + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                ExecSql(connString, str8);
            }
            int index = (parentPath + @"\").IndexOf(@"\" + fileMixId + @"\");
            string str9 = rootPath + @"\" + parentPath.Substring(0, index) + @"\" + fileMixId + @"\" + str5 + "00001";
            File.Copy(origFilePath, str9 + info.Extension.ToLower());
            string str10 = str9 + ".odf";
            return nextVal;
        }
        
        //by shira
        public static int InsertFile(string path, string id, string connString)
        {
            string last_id =id,beforelastid=id;
            string s = path;
            string type = "";
            string[] words = s.Split('\\');
            int i;
            string sql;
            DataTable dt; 
            for ( i = words.Length; i >0 ; i--)
            {
                sql = "select parent_id, type from tree_tab where id =" + last_id;
                 dt=GetDataTable(connString, sql);
                foreach (DataRow row in dt.Rows)
                {
                    beforelastid = last_id;
                    last_id = row[0].ToString();
                    type = row[1].ToString();
                }
               
                    if (type == "3" || type=="1")
                    break; 
            }
            if (i > 0 && type == "1")
            {
                return -10;
            }
            if (i > 0)
                return (path + @"\").IndexOf(@"\" + beforelastid + @"\")+beforelastid.Length+1;
            return 0;
        }
        public static string InsertNewFileMix(string connString, string name, string parentId, string parentPath, string rootPath, string docTypeId)
        {
            string nextVal = GetNextVal(connString, "item_seq");
            string str2 = parentPath + @"\" + nextVal;
            docTypeId = string.IsNullOrEmpty(docTypeId) ? "NULL" : docTypeId;
            string sql = "insert into tree_tab (id, book_id, parent_id, type, cfg_id, \r\n\t\t\t\t\torder_number, title, id_path) values (" + nextVal + "," + nextVal + "," + parentId + ",3," + docTypeId + ",999,'" + name.Replace("'", "''") + "','" + str2 + "')";
            ExecSql(connString, sql);
            string str4 = "insert into sm_tab (id, disk_folder, page_number_format) values ( " + nextVal + ",'" + str2 + "','00000')";
            ExecSql(connString, str4);
            if (docTypeId != "NULL")
            {
               string str5 = "insert into cfg_" + docTypeId + "_tab(id,column_1,column_2,column_3) Values ('" + nextVal + "','" + name + "','" + rootPath + @"\" + str2 + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
               // ?? string str5 = "insert into cfg_" + docTypeId + "_tab(id,column_1,column_2,column_3) Values ('" + nextVal + "','" + name + "','" + rootPath + @"\" + str2 + "','" + info.LastWriteTime + "')";
                ExecSql(connString, str5);
            }
            Directory.CreateDirectory(rootPath + @"\" + str2);
            return nextVal;
        }


    }
}

