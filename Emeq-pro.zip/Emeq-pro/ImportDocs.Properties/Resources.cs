﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ImportDocs.Properties
{
   /* class Resources
    {
    }
[System.CodeDom.Compiler.GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), DebuggerNonUserCode, CompilerGenerated]
internal class Resources
{
    // Fields
    private static CultureInfo resourceCulture;
    private static ResourceManager resourceMan;

    // Methods
    internal Resources()
    {
    }

    // Properties
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
        get => 
            resourceCulture;
        set
        {
            resourceCulture = value;
        }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
        get
        {
            if (resourceMan == null)
            {
                ResourceManager manager = new ResourceManager("ImportDocs.Properties.Resources", typeof(Resources).Assembly);
                resourceMan = manager;
            }
            return resourceMan;
        }
    }
}
    [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), DebuggerNonUserCode, CompilerGenerated]
internal class Resources
{
    // Fields
    private static CultureInfo resourceCulture;
    private static ResourceManager resourceMan;

    // Methods
    internal Resources();

    // Properties
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture { get; set; }
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager { get; }
}
*/
    [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), DebuggerNonUserCode, CompilerGenerated]
internal class Resources
{
    // Fields
   // private static CultureInfo resourceCulture;
    private static ResourceManager resourceMan;

    // Methods
    internal Resources()
    {
    }

    // Properties
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture { get; set; }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
        get
        {
            if (resourceMan == null)
            {
                ResourceManager manager = new ResourceManager("ImportDocs.Properties.Resources", typeof(Resources).Assembly);
                resourceMan = manager;
            }
            return resourceMan;
        }
    }
}
}
