﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ImportDocs.Properties
{
   /* class Settings
    {
    }
}
    [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0"), CompilerGenerated]
internal sealed class Settings : ApplicationSettingsBase
{
    // Fields
    private static Settings defaultInstance = ((Settings) SettingsBase.Synchronized(new Settings()));

    // Properties
    public static Settings Default =>
        defaultInstance;
}
    [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0"), CompilerGenerated]
    internal sealed class Settings : ApplicationSettingsBase
    {
        // Fields
        private static Settings defaultInstance;

        // Methods
        static Settings();
        public Settings();

        // Properties
        public static Settings Default { get; }
    }*/
    [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0"), CompilerGenerated]
internal sealed class Settings : ApplicationSettingsBase
{
    // Fields
    private static Settings defaultInstance = ((Settings) SettingsBase.Synchronized(new Settings()));

    // Properties
    public static Settings Default { get; set; }
}

}
 

