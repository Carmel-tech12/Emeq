﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImportDocs
{
    /*public partial class Form1 : Form
   {
      public Form1()
       {
           InitializeComponent();
       }*/
    public partial class Form1 : Form
    {
        // Fields
        private string _connString;
        private string _destinationId;
        private string _destinationPath;
        private string _dividerDocType;
        private string _documentDocType;
        private string _fileDocType;
        private DataNode _foldersData;
        private string _importRoot;
        private string _ocrRootPath;
        private string _supportedFileTypes;
        private int _totalFolders;
        private BackgroundWorker backgroundWorker1;
        private Label branchesLabel;
        private TreeView branchesTreeView;
        private Button button1;
        private Button button2;
        private IContainer components;
        private TreeView directoriesTreeView;
        private ComboBox dividerDocTypeComboBox;
        private ComboBox documentDocTypeComboBox;
        private ComboBox fileDocTypeComboBox;
        private ComboBox fileLevelComboBox;
        private Button globalAsaBrowseButton;
        private TextBox globalAsaTextBox;
        private ImageList iconImagesList;
        private Button importRootBrowseButton;
        private TextBox importRootTextBox;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private ProgressBar progressBar1;
        private TabControl tabControl1;
        private TableLayoutPanel tableLayoutPanel1;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel3;
        private TableLayoutPanel tableLayoutPanel4;
        private TabPage tabPage1;
        private TabPage tabPage2;

        // Methods
        public Form1()
        {
            this.InitializeComponent();
            this.fileLevelComboBox.SelectedIndex = 0;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            this.CopyNodeHierarchy(this._foldersData, this._destinationId, this._destinationPath, "");
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.progressBar1.Value++;
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            int num = (int)MessageBox.Show("Import finished successfully!");
            base.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num;
            if (this.globalAsaTextBox.Text == "")
            {
                num = (int)MessageBox.Show("Please select the global.asa file path");
                this.globalAsaBrowseButton.Focus();
            }
            else if (this.importRootTextBox.Text == "")
            {
                num = (int)MessageBox.Show("Please select the 'Import From' path");
                this.importRootBrowseButton.Focus();
            }
            else if ((this.dividerDocTypeComboBox.SelectedValue == null) || (this.dividerDocTypeComboBox.SelectedValue.ToString() == ""))
            {
                num = (int)MessageBox.Show("Please select the Default Doc Type for Divider");
                this.dividerDocTypeComboBox.Focus();
            }
            else if (this.branchesTreeView.SelectedNode == null)
            {
                num = (int)MessageBox.Show("Please select the 'Import into' branch");
                this.branchesTreeView.Focus();
            }
            else
            {
                this.label8.Visible = true;
                this.progressBar1.Minimum = 0;
                this.progressBar1.Maximum = this._totalFolders;
                this.progressBar1.Value = 0;
                this.progressBar1.Step = 1;
                this.progressBar1.Visible = true;
                TreeNode selectedNode = this.branchesTreeView.SelectedNode;
                this._destinationId = selectedNode.Tag.ToString();
                this._destinationPath = this._destinationId;
                while (selectedNode.Parent != null)
                {
                    selectedNode = selectedNode.Parent;
                    this._destinationPath = selectedNode.Tag.ToString() + @"\" + this._destinationPath;
                }
                this._foldersData = this.CopyFoldersDataIntoTree(this.directoriesTreeView.Nodes[0], null);
                this._fileDocType = this.fileDocTypeComboBox.SelectedValue.ToString();
                this._dividerDocType = this.dividerDocTypeComboBox.SelectedValue.ToString();
                this._documentDocType = this.documentDocTypeComboBox.SelectedValue.ToString();
                this.backgroundWorker1.RunWorkerAsync();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Title = "Select Dox Global.asa file",
                Filter = "Global.asa File|global.asa"
            };
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string globalAsaPath = this.globalAsaTextBox.Text = dialog.FileName.ToString();
                if (globalAsaPath != "")
                {
                    string str2;
                    string str3;
                    BuisenessLogic.GetDotNetConnectionString(globalAsaPath, out str2, out str3, out this._supportedFileTypes);
                    if (str2 == "")
                    {
                        int num = (int)MessageBox.Show("Could not find Connection String in the global.asa file");
                    }
                    else if (str3 == "")
                    {
                        int num2 = (int)MessageBox.Show("Could not find DSN in the global.asa file");
                    }
                    else
                    {
                        DataTable environmentsDataTable;
                        try
                        {
                            environmentsDataTable = BuisenessLogic.GetEnvironmentsDataTable(str2 + str3);
                        }
                        catch (Exception exception)
                        {
                            int num3 = (int)MessageBox.Show("Could not retrieve environments list (" + str2 + str3 + "): " + exception.Message);
                            return;
                        }
                        if (environmentsDataTable.Rows.Count == 0)
                        {
                            int num4 = (int)MessageBox.Show("No records found in the table env_tab (" + str2 + str3 + ")");
                        }
                        else
                        {
                            this._connString = str2 + environmentsDataTable.Rows[0]["dsn"];
                            this._ocrRootPath = environmentsDataTable.Rows[0]["ocr_files"].ToString();
                            this.FillDocTypeComboBoxes();
                            this.FillBranchesTreeView();
                        }
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog
            {
                Description = "Select the root directory to be imported into DOX"
            };
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.importRootTextBox.Text = this._importRoot = dialog.SelectedPath;
                base.UseWaitCursor = true;
                this._totalFolders = 0;
                this.directoriesTreeView.Nodes.Clear();
                this.directoriesTreeView.Nodes.Add(this.GetDirectoryNodes(new DirectoryInfo(this._importRoot)));
                this.directoriesTreeView.ExpandAll();
                this.SetDefaultIcons();
                base.UseWaitCursor = false;
            }
        }

        private DataNode CopyFoldersDataIntoTree(TreeNode treeNode, DataNode parent)
        {
            DataNode node = new DataNode
            {
                parent = parent,
                text = treeNode.Text,
                type = treeNode.ImageIndex,
                nodes = new List<DataNode>()
            };
            for (int i = 0; i < treeNode.Nodes.Count; i++)
            {
                node.nodes.Add(this.CopyFoldersDataIntoTree(treeNode.Nodes[i], node));
            }
            return node;
        }

        private void CopyNodeHierarchy(DataNode directoryNode, string destinationId, string destinationPath, string fileMixId)
        {
            string text = "";
            string str;
            string str2;
            DataNode node2;
            string[] filesWithMultipleExtensions;
            //  text = "the directoryNode:" + directoryNode + "  the destinationId is:" + destinationId + "  the destinationPath is:" + destinationPath + "the fileMixId is:" + fileMixId;
            //  System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write.txt", text);
            text = "the destinationPath is2:" + destinationPath;
            System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write111.txt", text);
            if (!insertfolder(destinationPath))
            {
                text = "the destinationPath is2:" + destinationPath;
                System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write.txt", text);
                if (directoryNode.type == 0)
                {
                    str = BuisenessLogic.InsertNewBranch(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath);
                }
                else if (directoryNode.type == 1)
                {
                    str = BuisenessLogic.InsertNewFileMix(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._fileDocType);
                    fileMixId = str;
                }
                else
                {
                    if (fileMixId == "")
                    {
                        destinationId = BuisenessLogic.InsertNewFileMix(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._fileDocType);
                        destinationPath = destinationPath + @"\" + destinationId;
                        fileMixId = destinationId;
                    }
                    str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, fileMixId);
                }
                foreach (DataNode node in directoryNode.nodes)
                {
                    this.CopyNodeHierarchy(node, str, destinationPath + @"\" + str, fileMixId);
                }
                str2 = "";
                for (node2 = directoryNode; node2.parent != null; node2 = node2.parent)
                {
                    str2 = @"\" + node2.text + str2;
                }
                filesWithMultipleExtensions = BuisenessLogic.GetFilesWithMultipleExtensions(this._importRoot + str2, this._supportedFileTypes);
                if (filesWithMultipleExtensions.Length > 0)
                {
                    if (directoryNode.type == 0)
                    {
                        destinationId = str;
                        destinationPath = destinationPath + @"\" + str;
                        str = BuisenessLogic.InsertNewFileMix(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._fileDocType);
                    }
                    if (directoryNode.type <= 1)
                    {
                        fileMixId = str;
                        destinationId = str;
                        destinationPath = destinationPath + @"\" + str;
                        str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, str);
                    }
                    foreach (string str3 in filesWithMultipleExtensions)
                    {
                        BuisenessLogic.InsertNewDocumentAndCopyFile(this._connString, new FileInfo(str3).Name, str, destinationPath + @"\" + str, this._ocrRootPath, this._documentDocType, fileMixId, str3);
                    }
                }
                this.backgroundWorker1.ReportProgress(0);
            }
            else
            {
                string destinationId2 = "", fileMixId2 = "";
                int i;
                //זימון פונקציה עבור בדיקה כמה תיקיות לייצר
                int result = NumOfFolder(destinationPath);
                bool degel = true;
                fileMixId = destinationId;
                //   while(result>0 && degel)
                //  {
                str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, fileMixId);
                foreach (DataNode node in directoryNode.nodes)
                {
                    this.CopyNodeHierarchy(node, str, destinationPath + @"\" + str, fileMixId);
                }
                str2 = "";
                for (node2 = directoryNode; node2.parent != null; node2 = node2.parent)
                {
                    str2 = @"\" + node2.text + str2;
                }
                filesWithMultipleExtensions = BuisenessLogic.GetFilesWithMultipleExtensions(this._importRoot + str2, this._supportedFileTypes);
                if (filesWithMultipleExtensions.Length > 0)
                {
                    if (directoryNode.type == 0)
                    {
                        degel = false;
                        destinationId = str;
                        destinationPath = destinationPath + @"\" + str;
                        str = BuisenessLogic.InsertNewFileMix(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._fileDocType);
                    }
                    System.IO.File.WriteAllText(@"D:\shira\Setup\try\directoryNodetype1.txt", "directoryNode.type is: " + directoryNode.type);
                    //  if (directoryNode.type > 0)
                    // degel = true;
                    if (directoryNode.type <= 1)
                    {
                        System.IO.File.WriteAllText(@"D:\shira\Setup\try\directoryNodetype.txt", "directoryNode.type is: " + directoryNode.type);
                        degel = false;
                        fileMixId = str;
                        destinationId = str;
                        destinationPath = destinationPath + @"\" + str;
                        str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, str);
                    }
                    /* if (directoryNode.type> 1)
                    {
                        // System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write.txt", "directoryNode.type is: " + directoryNode.type);
                        degel = false;
                        fileMixId = str;
                        destinationId = str;
                        destinationPath = destinationPath + @"\" + str;
                        str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, str);
                    }
                   else
                    {
                        int e = directoryNode.type;
                        while (e > 0)
                        {
                            System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write.txt", "directoryNode.type is: " + directoryNode.type);
                            fileMixId = str;
                            destinationId = str;
                            destinationPath = destinationPath + @"\" + str;
                            str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, str);
                            e--;
                        }

                    }
                  if (directoryNode.type > 1)
                    {
                        System.IO.File.WriteAllText(@"D:\shira\Setup\try\directoryNodetype2.txt", "directoryNode.type is: " + directoryNode.type);
                        //
                        i = 0;
                        fileMixId2 = destinationPath.Substring(destinationPath.LastIndexOf(@"\")-5,5);
                        System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write888.txt", fileMixId2);
                        System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write888org.txt", fileMixId);
                        destinationId2 = destinationPath.Substring(0,destinationPath.LastIndexOf(@"\"));
                        System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write55.txt", destinationId2);
                        //destinationPath = destinationPath + @"\" + str;
                        System.IO.File.WriteAllText(@"D:\shira\Setup\try\WriteShira.txt",( "this._connString "+this._connString+"directoryNode.text"+directoryNode.text+" destinationId2"+destinationId2+"destinationPath"+destinationPath+"this. _ocrRootPath"+ this._ocrRootPath+"  this._dividerDocType"+ this._dividerDocType+"  fileMixId"+ fileMixId2));
                       //....
                        fileMixId = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId2, destinationPath, this._ocrRootPath, this._dividerDocType, fileMixId2);
                        System.IO.File.WriteAllText(@"D:\shira\Setup\try\here6.txt","");
                      System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write11111111111111.txt", "str3 is:" + filesWithMultipleExtensions[0]);
                      foreach (string str3 in filesWithMultipleExtensions)
                        {
                            System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write55555555555.txt", "str3 is:" + str3);
                            BuisenessLogic.InsertNewDocumentAndCopyFile(this._connString, new FileInfo(str3).Name, fileMixId2, destinationPath , this._ocrRootPath, this._documentDocType, fileMixId2, str3);
                            System.IO.File.WriteAllText(@"D:\shira\Setup\try\WriteShiraEnter.txt", ("this._connString " + this._connString + "   directoryNode.text" + directoryNode.text + " destinationId2" + destinationId2 + "  destinationPath" + destinationPath + "this. _ocrRootPath" + this._ocrRootPath + "this._dividerDocType" + this._dividerDocType + "fileMixId" + fileMixId2));
                        }
                        //
                        fileMixId = str;
                        destinationId = str;
                        destinationPath = destinationPath + @"\" + str;
                        str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, str);
                    }
                }*/
                    if (directoryNode.type > 1)
                    {
                        i = 89;
                        foreach (string str3 in filesWithMultipleExtensions)
                        {
                            System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write" + i + ".txt", "str3 is:" + str3+"str: "+str);
                            i++;
                            System.IO.File.WriteAllText(@"D:\shira\Setup\try\Writetowrite" ," this._connString"+ this._connString+" new FileInfo(str3).Name"+ new FileInfo(str3).Name+" str"+ str+ "destinationPathstr"+ destinationPath+"this._ocrRootPath"+ this._ocrRootPath+"this._documentDocType"+ this._documentDocType+"fileMixId: "+ fileMixId+"str3: "+ str3);
                            BuisenessLogic.InsertNewDocumentAndCopyFile(this._connString, new FileInfo(str3).Name, str, destinationPath + @"\" + str, this._ocrRootPath, this._documentDocType, fileMixId, str3);
                        }
                        System.IO.File.WriteAllText(@"D:\shira\Setup\try\directoryNodetype.txt", "directoryNode.type is: " + directoryNode.type);
                        fileMixId = str;
                        destinationId = str;
                        destinationPath = destinationPath + @"\" + str;
                        str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, str);
                        System.IO.File.WriteAllText(@"D:\shira\Setup\try\here7.txt", "str " + str);

                    }
                    if (directoryNode.type > 1)
                        filesWithMultipleExtensions = BuisenessLogic.GetFilesWithMultipleExtensions(this._importRoot + str2, this._supportedFileTypes);
                    System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write.txt", "filesWithMultipleExtensions is: " + filesWithMultipleExtensions);
                    i = 100;
                    foreach (string str3 in filesWithMultipleExtensions)
                    {
                        System.IO.File.WriteAllText(@"D:\shira\Setup\try\Write" + i + ".txt", "str3 is:" + str3);
                        i++;
                        BuisenessLogic.InsertNewDocumentAndCopyFile(this._connString, new FileInfo(str3).Name, str, destinationPath + @"\" + str, this._ocrRootPath, this._documentDocType, fileMixId, str3);
                    }
                    // }
                    this.backgroundWorker1.ReportProgress(0);
                }
            }
        }
        public int NumOfFolder(string path)
        {
            //string[] separators = { ",", ".", "!", "?", ";", ":", " " };
           // string value = "The handsome, energetic, young dog was playing with his smaller, more lethargic litter mate.";
            string[] separators = { "/", ".", "!", "?", ";", ":", " " };
            string value = path;
            string[] words = value.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            return words.Count();
        }
        private void CopyNodeHierarchy2(DataNode directoryNode, string destinationId, string destinationPath, string fileMixId)
        {
            string str;
            string str2;
            DataNode node2;
            string[] filesWithMultipleExtensions;
            if (!insertfolder(destinationPath))
            {
                if (directoryNode.type == 0)
                {
                    str = BuisenessLogic.InsertNewBranch(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath);
                }
                else if (directoryNode.type == 1)
                {
                    str = BuisenessLogic.InsertNewFileMix(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._fileDocType);
                    fileMixId = str;
                }
                else
                {
                    if (fileMixId == "")
                    {
                        destinationId = BuisenessLogic.InsertNewFileMix(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._fileDocType);
                        destinationPath = destinationPath + @"\" + destinationId;
                        fileMixId = destinationId;
                    }
                    str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, fileMixId);
                }
                foreach (DataNode node in directoryNode.nodes)
                {
                    this.CopyNodeHierarchy(node, str, destinationPath + @"\" + str, fileMixId);
                }
                str2 = "";
                for (node2 = directoryNode; node2.parent != null; node2 = node2.parent)
                {
                    str2 = @"\" + node2.text + str2;
                }
                filesWithMultipleExtensions = BuisenessLogic.GetFilesWithMultipleExtensions(this._importRoot + str2, this._supportedFileTypes);
                if (filesWithMultipleExtensions.Length > 0)
                {
                    if (directoryNode.type == 0)
                    {
                        destinationId = str;
                        destinationPath = destinationPath + @"\" + str;
                        str = BuisenessLogic.InsertNewFileMix(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._fileDocType);
                    }
                    if (directoryNode.type <= 1)
                    {
                        fileMixId = str;
                        destinationId = str;
                        destinationPath = destinationPath + @"\" + str;
                        str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, str);
                    }
                    foreach (string str3 in filesWithMultipleExtensions)
                    {
                        BuisenessLogic.InsertNewDocumentAndCopyFile(this._connString, new FileInfo(str3).Name, str, destinationPath + @"\" + str, this._ocrRootPath, this._documentDocType, fileMixId, str3);
                    }
                }
                this.backgroundWorker1.ReportProgress(0);
            }
            else
            {
                fileMixId = destinationId;
                str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, fileMixId);
                foreach (DataNode node in directoryNode.nodes)
                {
                    this.CopyNodeHierarchy(node, str, destinationPath + @"\" + str, fileMixId);
                }
                str2 = "";
                for (node2 = directoryNode; node2.parent != null; node2 = node2.parent)
                {
                    str2 = @"\" + node2.text + str2;
                }
                filesWithMultipleExtensions = BuisenessLogic.GetFilesWithMultipleExtensions(this._importRoot + str2, this._supportedFileTypes);
                if (filesWithMultipleExtensions.Length > 0)
                {
                    if (directoryNode.type == 0)
                    {
                        destinationId = str;
                        destinationPath = destinationPath + @"\" + str;
                        str = BuisenessLogic.InsertNewFileMix(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._fileDocType);
                    }
                    if (directoryNode.type <= 1)
                    {
                        fileMixId = str;
                        destinationId = str;
                        destinationPath = destinationPath + @"\" + str;
                        str = BuisenessLogic.InsertNewDivider(this._connString, directoryNode.text, destinationId, destinationPath, this._ocrRootPath, this._dividerDocType, str);
                    }
                    foreach (string str3 in filesWithMultipleExtensions)
                    {
                        BuisenessLogic.InsertNewDocumentAndCopyFile(this._connString, new FileInfo(str3).Name, str, destinationPath + @"\" + str, this._ocrRootPath, this._documentDocType, fileMixId, str3);
                    }
                }
                this.backgroundWorker1.ReportProgress(0);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void fileLevelComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.SetDefaultIcons();
        }

        private void FillBranchesTreeView()
        {
            this.branchesTreeView.Nodes.Clear();
            DataTable booksTreeDataTable = BuisenessLogic.GetBooksTreeDataTable(this._connString);
            this.branchesTreeView.Visible = booksTreeDataTable.Rows.Count > 0;
            this.branchesLabel.Visible = booksTreeDataTable.Rows.Count > 0;
            TreeNode parent = null;
            foreach (DataRow row in booksTreeDataTable.Rows)
            {
                TreeNode node2;
                string str = row["id"].ToString();
                string str2 = row["parent_id"].ToString();
                string text = row["title"].ToString();
                TreeNodeCollection nodes = null;
                switch (str2)
                {
                    case "0":
                    case "":
                        nodes = this.branchesTreeView.Nodes;
                        goto Label_014C;

                    default:
                        while (parent != null)
                        {
                            if (parent.Tag.ToString() == str2)
                            {
                                nodes = parent.Nodes;
                                break;
                            }
                            parent = parent.Parent;
                        }
                        break;
                }
                if (nodes == null)
                {
                    int num = (int)MessageBox.Show("Book ID not found in the hierarchy:" + str2);
                    return;
                }
            Label_014C:
                node2 = new TreeNode(text, 0, 0);
                node2.Tag = str;
                nodes.Add(node2);
                parent = node2;
            }
            this.branchesTreeView.ExpandAll();
            if (this.branchesTreeView.Nodes.Count > 0)
            {
                this.branchesTreeView.SelectedNode = this.branchesTreeView.Nodes[0];
            }
        }

        private void FillDocTypeComboBoxes()
        {
            DataTable documentTypesDataTable = BuisenessLogic.GetDocumentTypesDataTable(this._connString);
            documentTypesDataTable.Rows.InsertAt(documentTypesDataTable.NewRow(), 0);
            ComboBox[] boxArray = new ComboBox[] { this.fileDocTypeComboBox, this.dividerDocTypeComboBox, this.documentDocTypeComboBox };
            foreach (ComboBox box in boxArray)
            {
                box.DataSource = documentTypesDataTable.Copy();
                box.DisplayMember = "doc_type_name";
                box.ValueMember = "doc_type_id";
            }
        }

        private TreeNode GetDirectoryNodes(DirectoryInfo dir)
        {
            this._totalFolders++;
            TreeNode node = new TreeNode(dir.Name);
            foreach (DirectoryInfo info in dir.GetDirectories())
            {
                node.Nodes.Add(this.GetDirectoryNodes(info));
            }
            return node;
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.tableLayoutPanel1 = new TableLayoutPanel();
            this.tabControl1 = new TabControl();
            this.tabPage1 = new TabPage();
            this.tableLayoutPanel4 = new TableLayoutPanel();
            this.globalAsaTextBox = new TextBox();
            this.label1 = new Label();
            this.globalAsaBrowseButton = new Button();
            this.label2 = new Label();
            this.importRootTextBox = new TextBox();
            this.importRootBrowseButton = new Button();
            this.label3 = new Label();
            this.fileLevelComboBox = new ComboBox();
            this.label4 = new Label();
            this.label5 = new Label();
            this.fileDocTypeComboBox = new ComboBox();
            this.label6 = new Label();
            this.dividerDocTypeComboBox = new ComboBox();
            this.label7 = new Label();
            this.documentDocTypeComboBox = new ComboBox();
            this.branchesTreeView = new TreeView();
            this.iconImagesList = new ImageList(this.components);
            this.branchesLabel = new Label();
            this.tabPage2 = new TabPage();
            this.tableLayoutPanel3 = new TableLayoutPanel();
            this.directoriesTreeView = new TreeView();
            this.tableLayoutPanel2 = new TableLayoutPanel();
            this.button2 = new Button();
            this.button1 = new Button();
            this.label8 = new Label();
            this.progressBar1 = new ProgressBar();
            this.backgroundWorker1 = new BackgroundWorker();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            base.SuspendLayout();
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            this.tableLayoutPanel1.Controls.Add(this.tabControl1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Dock = DockStyle.Fill;
            this.tableLayoutPanel1.Location = new Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 34f));
            this.tableLayoutPanel1.Size = new Size(0x31f, 530);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = DockStyle.Fill;
            this.tabControl1.Location = new Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new Size(0x319, 490);
            this.tabControl1.TabIndex = 1;
            this.tabPage1.BackColor = SystemColors.Control;
            this.tabPage1.Controls.Add(this.tableLayoutPanel4);
            this.tabPage1.Location = new Point(4, 0x16);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new Padding(3);
            this.tabPage1.Size = new Size(0x311, 0x1d0);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "General Settings";
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            this.tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 356f));
            this.tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 243f));
            this.tableLayoutPanel4.Controls.Add(this.globalAsaTextBox, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.globalAsaBrowseButton, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.importRootTextBox, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.importRootBrowseButton, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.fileLevelComboBox, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.label4, 2, 2);
            this.tableLayoutPanel4.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.fileDocTypeComboBox, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.label6, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.dividerDocTypeComboBox, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.label7, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.documentDocTypeComboBox, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.branchesTreeView, 0, 10);
            this.tableLayoutPanel4.Controls.Add(this.branchesLabel, 0, 9);
            this.tableLayoutPanel4.Dock = DockStyle.Fill;
            this.tableLayoutPanel4.Location = new Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 11;
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel4.Size = new Size(0x30b, 0x1ca);
            this.tableLayoutPanel4.TabIndex = 15;
            this.globalAsaTextBox.Location = new Point(0xb7, 3);
            this.globalAsaTextBox.Name = "globalAsaTextBox";
            this.globalAsaTextBox.Size = new Size(0x158, 20);
            this.globalAsaTextBox.TabIndex = 1;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x4c, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Global.asa file:";
            this.globalAsaBrowseButton.Location = new Point(0x21b, 3);
            this.globalAsaBrowseButton.Name = "globalAsaBrowseButton";
            this.globalAsaBrowseButton.Size = new Size(0x19, 20);
            this.globalAsaBrowseButton.TabIndex = 2;
            this.globalAsaBrowseButton.Text = "...";
            this.globalAsaBrowseButton.UseVisualStyleBackColor = true;
            this.globalAsaBrowseButton.Click += new EventHandler(this.button3_Click);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(3, 0x1a);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x41, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Import From:";
            this.importRootTextBox.Location = new Point(0xb7, 0x1d);
            this.importRootTextBox.Name = "importRootTextBox";
            this.importRootTextBox.Size = new Size(0x158, 20);
            this.importRootTextBox.TabIndex = 4;
            this.importRootBrowseButton.Location = new Point(0x21b, 0x1d);
            this.importRootBrowseButton.Name = "importRootBrowseButton";
            this.importRootBrowseButton.Size = new Size(0x19, 20);
            this.importRootBrowseButton.TabIndex = 5;
            this.importRootBrowseButton.Text = "...";
            this.importRootBrowseButton.UseVisualStyleBackColor = true;
            this.importRootBrowseButton.Click += new EventHandler(this.button4_Click);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(3, 0x34);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x53, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "File(MIX) is level";
            this.fileLevelComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.fileLevelComboBox.FormattingEnabled = true;
            this.fileLevelComboBox.Items.AddRange(new object[] { "2", "3", "4", "5", "6", "7", "8", "9", "10" });
            this.fileLevelComboBox.Location = new Point(0xb7, 0x37);
            this.fileLevelComboBox.Name = "fileLevelComboBox";
            this.fileLevelComboBox.Size = new Size(0x24, 0x15);
            this.fileLevelComboBox.TabIndex = 7;
            this.fileLevelComboBox.SelectedIndexChanged += new EventHandler(this.fileLevelComboBox_SelectedIndexChanged);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x21b, 0x34);
            this.label4.Name = "label4";
            this.label4.Size = new Size(80, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "from the bottom";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(3, 0x4e);
            this.label5.Name = "label5";
            this.label5.Size = new Size(150, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Default Doc Type for File(MIX)";
            this.fileDocTypeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.fileDocTypeComboBox.FormattingEnabled = true;
            this.fileDocTypeComboBox.Location = new Point(0xb7, 0x51);
            this.fileDocTypeComboBox.Name = "fileDocTypeComboBox";
            this.fileDocTypeComboBox.Size = new Size(0xd5, 0x15);
            this.fileDocTypeComboBox.TabIndex = 10;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(3, 0x68);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x8e, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Default Doc Type for Divider";
            this.dividerDocTypeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.dividerDocTypeComboBox.FormattingEnabled = true;
            this.dividerDocTypeComboBox.Location = new Point(0xb7, 0x6b);
            this.dividerDocTypeComboBox.Name = "dividerDocTypeComboBox";
            this.dividerDocTypeComboBox.Size = new Size(0xd5, 0x15);
            this.dividerDocTypeComboBox.TabIndex = 12;
            this.label7.AutoSize = true;
            this.label7.Location = new Point(3, 130);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x9e, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Default Doc Type for Document";
            this.documentDocTypeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.documentDocTypeComboBox.FormattingEnabled = true;
            this.documentDocTypeComboBox.Location = new Point(0xb7, 0x85);
            this.documentDocTypeComboBox.Name = "documentDocTypeComboBox";
            this.documentDocTypeComboBox.Size = new Size(0xd5, 0x15);
            this.documentDocTypeComboBox.TabIndex = 14;
            this.tableLayoutPanel4.SetColumnSpan(this.branchesTreeView, 3);
            this.branchesTreeView.Dock = DockStyle.Fill;
            this.branchesTreeView.HideSelection = false;
            this.branchesTreeView.ImageIndex = 0;
            this.branchesTreeView.ImageList = this.iconImagesList;
            this.branchesTreeView.Location = new Point(3, 0xef);
            this.branchesTreeView.Name = "branchesTreeView";
            this.branchesTreeView.SelectedImageIndex = 0;
            this.branchesTreeView.Size = new Size(0x305, 0xd8);
            this.branchesTreeView.TabIndex = 15;
            this.iconImagesList.ColorDepth = ColorDepth.Depth8Bit;
            this.iconImagesList.ImageSize = new Size(0x10, 0x10);
            this.iconImagesList.TransparentColor = Color.Transparent;
            this.branchesLabel.AutoSize = true;
            this.branchesLabel.Location = new Point(3, 0xd8);
            this.branchesLabel.Name = "branchesLabel";
            this.branchesLabel.Size = new Size(0x5f, 13);
            this.branchesLabel.TabIndex = 0x10;
            this.branchesLabel.Text = "Import into branch:";
            this.tabPage2.Controls.Add(this.tableLayoutPanel3);
            this.tabPage2.Location = new Point(4, 0x16);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new Padding(3);
            this.tabPage2.Size = new Size(0x311, 0x1d0);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Details";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70f));
            this.tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30f));
            this.tableLayoutPanel3.Controls.Add(this.directoriesTreeView, 0, 0);
            this.tableLayoutPanel3.Dock = DockStyle.Fill;
            this.tableLayoutPanel3.Location = new Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            this.tableLayoutPanel3.Size = new Size(0x30b, 0x1ca);
            this.tableLayoutPanel3.TabIndex = 0;
            this.directoriesTreeView.Dock = DockStyle.Fill;
            this.directoriesTreeView.ImageIndex = 0;
            this.directoriesTreeView.ImageList = this.iconImagesList;
            this.directoriesTreeView.Location = new Point(3, 3);
            this.directoriesTreeView.Name = "directoriesTreeView";
            this.directoriesTreeView.SelectedImageIndex = 0;
            this.directoriesTreeView.Size = new Size(0x21b, 0x1c4);
            this.directoriesTreeView.TabIndex = 0;
            this.tableLayoutPanel2.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 27.88461f));
            this.tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 72.11539f));
            this.tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 81f));
            this.tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 84f));
            this.tableLayoutPanel2.Controls.Add(this.button2, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.button1, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.progressBar1, 1, 0);
            this.tableLayoutPanel2.Location = new Point(0x141, 0x1f3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel2.Size = new Size(0x1db, 0x1c);
            this.tableLayoutPanel2.TabIndex = 0;
            this.button2.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.button2.Location = new Point(0x18f, 3);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x49, 0x16);
            this.button2.TabIndex = 1;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.button1.Location = new Point(0x138, 3);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x16);
            this.button1.TabIndex = 0;
            this.button1.Text = "Import";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label8.AutoSize = true;
            this.label8.Location = new Point(3, 0);
            this.label8.Name = "label8";
            this.label8.Size = new Size(80, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Importing files...";
            this.label8.Visible = false;
            this.progressBar1.Location = new Point(0x59, 3);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xd9, 0x16);
            this.progressBar1.TabIndex = 3;
            this.progressBar1.Visible = false;
            this.backgroundWorker1.WorkerReportsProgress = true;
            this.backgroundWorker1.DoWork += new DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.ProgressChanged += new ProgressChangedEventHandler(this.backgroundWorker1_ProgressChanged);
            this.backgroundWorker1.RunWorkerCompleted += new RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            base.ClientSize = new Size(0x31f, 530);
            base.Controls.Add(this.tableLayoutPanel1);
            base.Name = "Form1";
            this.Text = "Import external documents into DOX";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            base.ResumeLayout(false);
        }

        private void InitializeComponent2()
        {
            this.components = new Container();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(Form1));
            this.tableLayoutPanel1 = new TableLayoutPanel();
            this.tabControl1 = new TabControl();
            this.tabPage1 = new TabPage();
            this.tableLayoutPanel4 = new TableLayoutPanel();
            this.globalAsaTextBox = new TextBox();
            this.label1 = new Label();
            this.globalAsaBrowseButton = new Button();
            this.label2 = new Label();
            this.importRootTextBox = new TextBox();
            this.importRootBrowseButton = new Button();
            this.label3 = new Label();
            this.fileLevelComboBox = new ComboBox();
            this.label4 = new Label();
            this.label5 = new Label();
            this.fileDocTypeComboBox = new ComboBox();
            this.label6 = new Label();
            this.dividerDocTypeComboBox = new ComboBox();
            this.label7 = new Label();
            this.documentDocTypeComboBox = new ComboBox();
            this.branchesTreeView = new TreeView();
            this.iconImagesList = new ImageList(this.components);
            this.branchesLabel = new Label();
            this.tabPage2 = new TabPage();
            this.tableLayoutPanel3 = new TableLayoutPanel();
            this.directoriesTreeView = new TreeView();
            this.tableLayoutPanel2 = new TableLayoutPanel();
            this.button2 = new Button();
            this.button1 = new Button();
            this.label8 = new Label();
            this.progressBar1 = new ProgressBar();
            this.backgroundWorker1 = new BackgroundWorker();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            base.SuspendLayout();
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            this.tableLayoutPanel1.Controls.Add(this.tabControl1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Dock = DockStyle.Fill;
            this.tableLayoutPanel1.Location = new Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 34f));
            this.tableLayoutPanel1.Size = new Size(0x31f, 530);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = DockStyle.Fill;
            this.tabControl1.Location = new Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new Size(0x319, 490);
            this.tabControl1.TabIndex = 1;
            this.tabPage1.BackColor = SystemColors.Control;
            this.tabPage1.Controls.Add(this.tableLayoutPanel4);
            this.tabPage1.Location = new Point(4, 0x16);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new Padding(3);
            this.tabPage1.Size = new Size(0x311, 0x1d0);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "General Settings";
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            this.tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 356f));
            this.tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 243f));
            this.tableLayoutPanel4.Controls.Add(this.globalAsaTextBox, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.globalAsaBrowseButton, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.importRootTextBox, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.importRootBrowseButton, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.fileLevelComboBox, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.label4, 2, 2);
            this.tableLayoutPanel4.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.fileDocTypeComboBox, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.label6, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.dividerDocTypeComboBox, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.label7, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.documentDocTypeComboBox, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.branchesTreeView, 0, 10);
            this.tableLayoutPanel4.Controls.Add(this.branchesLabel, 0, 9);
            this.tableLayoutPanel4.Dock = DockStyle.Fill;
            this.tableLayoutPanel4.Location = new Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 11;
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel4.Size = new Size(0x30b, 0x1ca);
            this.tableLayoutPanel4.TabIndex = 15;
            this.globalAsaTextBox.Location = new Point(0xb7, 3);
            this.globalAsaTextBox.Name = "globalAsaTextBox";
            this.globalAsaTextBox.Size = new Size(0x158, 20);
            this.globalAsaTextBox.TabIndex = 1;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x4c, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Global.asa file:";
            this.globalAsaBrowseButton.Location = new Point(0x21b, 3);
            this.globalAsaBrowseButton.Name = "globalAsaBrowseButton";
            this.globalAsaBrowseButton.Size = new Size(0x19, 20);
            this.globalAsaBrowseButton.TabIndex = 2;
            this.globalAsaBrowseButton.Text = "...";
            this.globalAsaBrowseButton.UseVisualStyleBackColor = true;
            this.globalAsaBrowseButton.Click += new EventHandler(this.button3_Click);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(3, 0x1a);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x41, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Import From:";
            this.importRootTextBox.Location = new Point(0xb7, 0x1d);
            this.importRootTextBox.Name = "importRootTextBox";
            this.importRootTextBox.Size = new Size(0x158, 20);
            this.importRootTextBox.TabIndex = 4;
            this.importRootBrowseButton.Location = new Point(0x21b, 0x1d);
            this.importRootBrowseButton.Name = "importRootBrowseButton";
            this.importRootBrowseButton.Size = new Size(0x19, 20);
            this.importRootBrowseButton.TabIndex = 5;
            this.importRootBrowseButton.Text = "...";
            this.importRootBrowseButton.UseVisualStyleBackColor = true;
            this.importRootBrowseButton.Click += new EventHandler(this.button4_Click);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(3, 0x34);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x53, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "File(MIX) is level";
            this.fileLevelComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.fileLevelComboBox.FormattingEnabled = true;
            this.fileLevelComboBox.Items.AddRange(new object[] { "2", "3", "4", "5", "6", "7", "8", "9", "10" });
            this.fileLevelComboBox.Location = new Point(0xb7, 0x37);
            this.fileLevelComboBox.Name = "fileLevelComboBox";
            this.fileLevelComboBox.Size = new Size(0x24, 0x15);
            this.fileLevelComboBox.TabIndex = 7;
            this.fileLevelComboBox.SelectedIndexChanged += new EventHandler(this.fileLevelComboBox_SelectedIndexChanged);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x21b, 0x34);
            this.label4.Name = "label4";
            this.label4.Size = new Size(80, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "from the bottom";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(3, 0x4e);
            this.label5.Name = "label5";
            this.label5.Size = new Size(150, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Default Doc Type for File(MIX)";
            this.fileDocTypeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.fileDocTypeComboBox.FormattingEnabled = true;
            this.fileDocTypeComboBox.Location = new Point(0xb7, 0x51);
            this.fileDocTypeComboBox.Name = "fileDocTypeComboBox";
            this.fileDocTypeComboBox.Size = new Size(0xd5, 0x15);
            this.fileDocTypeComboBox.TabIndex = 10;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(3, 0x68);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x8e, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Default Doc Type for Divider";
            this.dividerDocTypeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.dividerDocTypeComboBox.FormattingEnabled = true;
            this.dividerDocTypeComboBox.Location = new Point(0xb7, 0x6b);
            this.dividerDocTypeComboBox.Name = "dividerDocTypeComboBox";
            this.dividerDocTypeComboBox.Size = new Size(0xd5, 0x15);
            this.dividerDocTypeComboBox.TabIndex = 12;
            this.label7.AutoSize = true;
            this.label7.Location = new Point(3, 130);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x9e, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Default Doc Type for Document";
            this.documentDocTypeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.documentDocTypeComboBox.FormattingEnabled = true;
            this.documentDocTypeComboBox.Location = new Point(0xb7, 0x85);
            this.documentDocTypeComboBox.Name = "documentDocTypeComboBox";
            this.documentDocTypeComboBox.Size = new Size(0xd5, 0x15);
            this.documentDocTypeComboBox.TabIndex = 14;
            this.tableLayoutPanel4.SetColumnSpan(this.branchesTreeView, 3);
            this.branchesTreeView.Dock = DockStyle.Fill;
            this.branchesTreeView.HideSelection = false;
            this.branchesTreeView.ImageIndex = 0;
            this.branchesTreeView.ImageList = this.iconImagesList;
            this.branchesTreeView.Location = new Point(3, 0xef);
            this.branchesTreeView.Name = "branchesTreeView";
            this.branchesTreeView.SelectedImageIndex = 0;
            this.branchesTreeView.Size = new Size(0x305, 0xd8);
            this.branchesTreeView.TabIndex = 15;
            this.iconImagesList.ImageStream = (ImageListStreamer)manager.GetObject("iconImagesList.ImageStream");
            this.iconImagesList.TransparentColor = Color.Transparent;
            MessageBox.Show(this.iconImagesList.Images.Count.ToString());
            this.iconImagesList.Images.SetKeyName(0, "branch.gif");
            this.iconImagesList.Images.SetKeyName(1, "file.gif");
            this.iconImagesList.Images.SetKeyName(2, "divider.gif");
            MessageBox.Show(this.iconImagesList.Images.Count.ToString());
            this.branchesLabel.AutoSize = true;
            this.branchesLabel.Location = new Point(3, 0xd8);
            this.branchesLabel.Name = "branchesLabel";
            this.branchesLabel.Size = new Size(0x5f, 13);
            this.branchesLabel.TabIndex = 0x10;
            this.branchesLabel.Text = "Import into branch:";
            this.tabPage2.Controls.Add(this.tableLayoutPanel3);
            this.tabPage2.Location = new Point(4, 0x16);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new Padding(3);
            this.tabPage2.Size = new Size(0x311, 0x1d0);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Details";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70f));
            this.tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30f));
            this.tableLayoutPanel3.Controls.Add(this.directoriesTreeView, 0, 0);
            this.tableLayoutPanel3.Dock = DockStyle.Fill;
            this.tableLayoutPanel3.Location = new Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            this.tableLayoutPanel3.Size = new Size(0x30b, 0x1ca);
            this.tableLayoutPanel3.TabIndex = 0;
            this.directoriesTreeView.Dock = DockStyle.Fill;
            this.directoriesTreeView.ImageIndex = 0;
            this.directoriesTreeView.ImageList = this.iconImagesList;
            this.directoriesTreeView.Location = new Point(3, 3);
            this.directoriesTreeView.Name = "directoriesTreeView";
            this.directoriesTreeView.SelectedImageIndex = 0;
            this.directoriesTreeView.Size = new Size(0x21b, 0x1c4);
            this.directoriesTreeView.TabIndex = 0;
            this.tableLayoutPanel2.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 27.88461f));
            this.tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 72.11539f));
            this.tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 81f));
            this.tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 84f));
            this.tableLayoutPanel2.Controls.Add(this.button2, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.button1, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.progressBar1, 1, 0);
            this.tableLayoutPanel2.Location = new Point(0x141, 0x1f3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel2.Size = new Size(0x1db, 0x1c);
            this.tableLayoutPanel2.TabIndex = 0;
            this.button2.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.button2.Location = new Point(0x18f, 3);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x49, 0x16);
            this.button2.TabIndex = 1;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.button1.Location = new Point(0x138, 3);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x16);
            this.button1.TabIndex = 0;
            this.button1.Text = "Import";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label8.AutoSize = true;
            this.label8.Location = new Point(3, 0);
            this.label8.Name = "label8";
            this.label8.Size = new Size(80, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Importing files...";
            this.label8.Visible = false;
            this.progressBar1.Location = new Point(0x59, 3);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xd9, 0x16);
            this.progressBar1.TabIndex = 3;
            this.progressBar1.Visible = false;
            this.backgroundWorker1.WorkerReportsProgress = true;
            this.backgroundWorker1.DoWork += new DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.ProgressChanged += new ProgressChangedEventHandler(this.backgroundWorker1_ProgressChanged);
            this.backgroundWorker1.RunWorkerCompleted += new RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x31f, 530);
            base.Controls.Add(this.tableLayoutPanel1);
            base.Name = "Form1";
            this.Text = "Import external documents into DOX";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            base.ResumeLayout(false);
        }

        public static bool insertfolder(string destinationPath)
        {
            string str = @"\";
            return destinationPath.Contains(str);
        }

        private int SetDefaultIcons()
        {
            if (this.directoriesTreeView.Nodes.Count > 0)
            {
                return this.SetDefaultIcons(this.directoriesTreeView.Nodes[0]);
            }
            return 0;
        }

        private int SetDefaultIcons(TreeNode node)
        {
            int num = 0;
            foreach (TreeNode node2 in node.Nodes)
            {
                num = Math.Max(this.SetDefaultIcons(node2), num);
            }
            int num2 = num + 1;
            int num3 = int.Parse(this.fileLevelComboBox.SelectedItem.ToString());
            node.ImageIndex = (num2 >= num3) ? ((num2 != num3) ? (node.SelectedImageIndex = 0) : (node.SelectedImageIndex = 1)) : (node.SelectedImageIndex = 2);
            return num2;
        }
    }
}
 
